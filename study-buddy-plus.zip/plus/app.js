'use strict';
// ===== 設定 =====
const KEY = 'gakushu-app:v1';   // 保存キー(アプリ固有)
const DATA_VER = 1, APP_VER = '0.1.0';
const $ = s => document.querySelector(s);
// 入力をHTMLとして実行させないための変換
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let tab = 'today', range = '7', msg = '', broken = false, draft = {};
let cal = null, selDay = null, lastDue = false;

// ===== 保存(localStorage) =====
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const d = JSON.parse(raw);
    if (!Array.isArray(d.records)) throw 0;
    return d.records;
  } catch (e) { broken = true; return []; }   // 壊れていたら上書きしない
}
function save(recs) {
  if (broken) { msg = '保存データが読めないため、上書きを止めました。「保存」画面でJSONを書き出せる場合は先に書き出してください。'; return false; }
  try { localStorage.setItem(KEY, JSON.stringify({ version: DATA_VER, records: recs })); return true; }
  catch (e) { msg = '保存できませんでした。ブラウザの保存容量や、プライベートモードの設定を確認してください。この記録は残っていません。'; return false; }
}
// 最新の保存内容を読み直してから変更する(複数タブ・連打対策)。fnがfalseを返したら何もしない。
function mutate(id, fn) {
  const recs = load(), r = recs.find(x => x.id === id);
  if (r && fn(r) !== false) { msg = ''; save(recs); }
  render();
}

// ===== 時間計算(保存した時刻と現在時刻から求める) =====
const t = iso => +new Date(iso);
function measured(r, at = Date.now()) {   // 計測時間(ms)=終了-開始-一時停止の合計
  const end = r.endedAt ? t(r.endedAt) : at;
  let p = 0;
  for (const q of r.pauses) p += (q.e ? t(q.e) : end) - t(q.s);
  return Math.max(0, end - t(r.startedAt) - p);
}
const fmt = ms => { const s = Math.floor(ms / 1000); return [s / 3600 | 0, (s % 3600) / 60 | 0, s % 60].map(n => String(n).padStart(2, '0')).join(':'); };
const local = iso => iso ? new Date(iso).toLocaleString('ja-JP', { dateStyle: 'short', timeStyle: 'short' }) : '';
const ldt = d => new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16);
const startDiff = r => (r.mode === 'planned' && r.plannedStart && r.startedAt) ? Math.round((t(r.startedAt) - t(r.plannedStart)) / 6e4) : null;

// ===== 操作 =====
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
function readForm() {
  const g = n => ($('#' + n)?.value || '').trim();
  return { subject: g('subject'), task: g('task'), firstStep: g('firstStep'), endCond: g('endCond'), plannedStart: g('plannedStart'), work: g('work'), brk: g('brk') };
}
function addPlan(now) {
  const f = readForm();
  if (!f.subject || !f.task || !f.firstStep || !f.endCond || (!now && !f.plannedStart)) { msg = '未入力の項目があります。教科・課題・最初の一歩・終了条件' + (now ? '' : '・開始予定') + 'を入れてください。'; draft = f; return render(); }
  const recs = load();
  if (recs.some(r => ['running', 'paused', 'ended'].includes(r.status))) { msg = '進行中の学習があります。'; return render(); }
  const w = Math.round(+f.work), b = Math.round(+f.brk);
  if (!(w >= 0 && w <= 180) || !(b >= 0 && b <= 60)) { msg = '区切りは0〜180分、休憩は0〜60分で入れてください(0は使わない)。'; draft = f; return render(); }
  const edit = draft.editId && recs.find(r => r.id === draft.editId && r.status === 'planned');
  const r = edit || { id: uid(), v: DATA_VER, appV: APP_VER, createdAt: new Date().toISOString(), pauses: [], focus: null, edited: false };
  Object.assign(r, { work: w, brk: b, seg: 1, status: 'planned', mode: now ? 'now' : 'planned', subject: f.subject, task: f.task, firstStep: f.firstStep, endCond: f.endCond, plannedStart: now ? null : new Date(f.plannedStart).toISOString() });
  if (!edit) recs.push(r);
  draft = {}; msg = '';
  if (!save(recs)) return render();
  if (now) startRec(r.id); else render();
}
function startRec(id) {
  mutate(id, r => {
    if (r.status !== 'planned') return false;              // 二重開始を防ぐ
    if (load().some(x => ['running', 'paused', 'ended'].includes(x.status))) return false;
    r.planSnapshot = { subject: r.subject, task: r.task, plannedStart: r.plannedStart, firstStep: r.firstStep, endCond: r.endCond }; // 開始時点の計画を残す
    r.startedAt = new Date().toISOString(); r.status = 'running';
  });
}
const pause = id => mutate(id, r => { if (r.status !== 'running') return false; r.pauses.push({ s: new Date().toISOString(), e: null }); r.status = 'paused'; });
const resume = id => mutate(id, r => { if (r.status !== 'paused') return false; r.pauses[r.pauses.length - 1].e = new Date().toISOString(); r.status = 'running'; if (r.work > 0) r.seg = Math.floor(measured(r) / (r.work * 6e4)) + 1; });
const more = id => mutate(id, r => { if (r.status !== 'running' || !(r.work > 0)) return false; r.seg = Math.floor(measured(r) / (r.work * 6e4)) + 1; });  // 「もう少し続ける」:次の区切りは今から1区切り先
const finish = id => mutate(id, r => {
  if (r.status !== 'running' && r.status !== 'paused') return false;   // 終了後の再終了を防ぐ
  const now = new Date().toISOString();
  if (r.status === 'paused') r.pauses[r.pauses.length - 1].e = now;
  r.endedAt = now; r.status = 'ended';
});
function saveReflect(id) {
  const a = document.querySelector('input[name=ach]:checked'), f = document.querySelector('input[name=foc]:checked');
  if (!a) { msg = '終了条件の達成状況を選んでください。'; return render(); }
  const endV = $('#endAt').value;
  mutate(id, r => {
    if (r.status !== 'ended') return false;
    if (endV) {   // 終了日時を直したときは「修正した記録」として残す
      const ne = new Date(endV);
      if (ne > t(r.startedAt) && ne.toISOString().slice(0, 16) !== r.endedAt.slice(0, 16)) { r.endedAtOriginal = r.endedAt; r.endedAt = ne.toISOString(); r.edited = true; r.pauses = r.pauses.filter(q => t(q.s) < ne); r.pauses.forEach(q => { if (q.e && t(q.e) > ne) q.e = r.endedAt; }); }
    }
    r.achieve = a.value; r.focus = f ? +f.value : null;
    r.trouble = $('#trouble').value.trim(); r.next = $('#next').value.trim(); r.status = 'done';
  });
}

// ===== 画面 =====
const ACH = { full: '達成', part: '一部達成', none: '未達成' };
function render() {
  document.querySelectorAll('nav button').forEach(b => b.setAttribute('aria-current', b.dataset.id === tab));
  const recs = load();
  let h = msg ? `<div class="err" role="alert">${esc(msg)}</div>` : '';
  if (broken) h += '<div class="err" role="alert">保存データを読み込めませんでした。新しい記録は保存されません。</div>';
  const act = recs.find(r => ['running', 'paused', 'ended'].includes(r.status));
  if (tab === 'today') h += act ? (act.status === 'ended' ? reflectView(act) : sessionView(act)) : planView(recs);
  else if (tab === 'log') h += logView(recs);
  else if (tab === 'cal') h += calView(recs);
  else if (tab === 'task') h += taskView();
  else h += dataView(recs);
  $('#app').innerHTML = h;
}
function planView(recs) {
  const d = draft, nexts = recs.filter(r => r.status === 'done' && r.next).slice(-5).reverse();
  const planned = recs.filter(r => r.status === 'planned');
  return `${adviceView(recs)}<section><h2>今日の学習を決める</h2>
<label for="subject">教科</label><input id="subject" value="${esc(d.subject)}" placeholder="例:数学">
<label for="task">取り組む課題</label><input id="task" value="${esc(d.task)}" placeholder="例:二次関数の問題">
<label for="plannedStart">開始予定日時(「今から始める」なら不要)</label><input id="plannedStart" type="datetime-local" value="${esc(d.plannedStart || ldt(new Date(Date.now() + 36e5)))}">
<label for="firstStep">最初の一歩</label><input id="firstStep" value="${esc(d.firstStep)}" placeholder="例:問題1の図を描く">
<label for="endCond">終了条件</label><input id="endCond" value="${esc(d.endCond)}" placeholder="例:問題1〜3を解き、誤りを確認する">
<label for="work">学習の区切り(分・0なら使わない)</label><input id="work" type="number" min="0" max="180" value="${esc(d.work ?? 25)}" ${d.work !== undefined ? 'data-t="1"' : ''}>
<label for="brk">休憩の目安(分)</label><input id="brk" type="number" min="0" max="60" value="${esc(d.brk ?? 5)}" ${d.brk !== undefined ? 'data-t="1"' : ''}>
<p class="note">教科に合わせて最初の値を入れますが、最適な長さを示すものではありません。自由に変えてください。</p>
${nexts.length ? `<p class="note">前に決めた「次回試すこと」(押すと最初の一歩に入ります)</p>` + nexts.map(r => `<button data-act="take" data-id="${esc(r.id)}">${esc(r.next)}</button>`).join(' ') : ''}
<div class="row"><button class="p" data-act="plan">予定として保存</button><button class="p" data-act="plannow">今から始める</button></div></section>
${planned.length ? '<section><h2>予定した学習</h2>' + planned.map(r => `<div class="rec"><b>${esc(r.subject)}</b> ${esc(r.task)}<br>開始予定 ${esc(local(r.plannedStart))}<div class="row"><button class="p" data-act="start" data-id="${esc(r.id)}">学習を始める</button><button data-act="edit" data-id="${esc(r.id)}">編集</button></div></div>`).join('') + '</section>' : ''}`;
}
function sessionView(r) {
  return `<section><p class="note">${esc(r.subject)}</p><p>今する課題</p><div class="big">${esc(r.task)}</div><p>終了条件</p><div class="big">${esc(r.endCond)}</div>
<div id="clock" aria-live="off">${fmt(measured(r))}</div>${breakNote(r)}
<div class="row">${r.status === 'paused' ? `<button class="p" data-act="resume" data-id="${esc(r.id)}">再開</button>` : `<button data-act="pause" data-id="${esc(r.id)}">一時停止</button>`}<button class="p" data-act="finish" data-id="${esc(r.id)}">学習を終える</button></div></section>`;
}
function reflectView(r) {
  const radios = (n, o) => o.map(([v, l]) => `<label class="opt"><input type="radio" name="${n}" value="${v}">${l}</label>`).join('');
  return `<section><h2>短く振り返る</h2><p class="note">計測時間 ${fmt(measured(r))}。いつでも途中でやめて大丈夫です。</p>
<fieldset><legend><b>終了条件はどうでしたか</b></legend>${radios('ach', [['full', '達成'], ['part', '一部達成'], ['none', '未達成']])}</fieldset>
<fieldset><legend><b>今回の学習にどのくらい集中できましたか(任意)</b></legend><span class="note">1=まったく集中できなかった 5=とても集中できた</span><br>${radios('foc', [1, 2, 3, 4, 5].map(n => [n, n]))}</fieldset>
<label for="trouble">困ったこと(任意)</label><input id="trouble"><label for="next">次回試すこと(任意)</label><input id="next">
<label for="endAt">終了日時(終了を忘れていたら直せます)</label><input id="endAt" type="datetime-local" value="${ldt(new Date(r.endedAt))}">
<div class="row"><button class="p" data-act="reflect" data-id="${esc(r.id)}">保存する</button></div></section>`;
}
function logView(all) {
  const done = all.filter(r => r.status === 'done');
  const lim = Date.now() - 7 * 864e5;
  const rs = (range === '7' ? done.filter(r => t(r.startedAt) >= lim) : done).sort((a, b) => t(b.startedAt) - t(a.startedAt));
  const dif = rs.map(startDiff).filter(x => x !== null);
  const sum = `<p>対象:${range === '7' ? '直近7日' : '全期間'}・${rs.length}件。計測時間の合計 ${Math.round(rs.reduce((s, r) => s + measured(r), 0) / 6e4)}分。` + (dif.length ? `予定どおりの開始時刻との差の平均 ${(dif.reduce((a, b) => a + b, 0) / dif.length).toFixed(1)}分(予定あり${dif.length}件。マイナスは早め)。` : '') + '</p><p class="note">計測時間はアプリの操作記録から求めた時間で、実際に勉強していたことを保証するものではありません。</p>';
  return `<section><h2>自分の記録</h2><div class="row"><button data-act="range" data-id="7" aria-pressed="${range === '7'}">直近7日</button><button data-act="range" data-id="all" aria-pressed="${range === 'all'}">全期間</button></div>${sum}` +
    (rs.length ? rs.map(r => { const d = startDiff(r); return `<div class="rec"><b>${esc(r.subject)}</b> ${esc(r.task)}${r.edited ? ' (終了日時を修正)' : ''}<br>${esc(local(r.plannedStart) || '予定なし(今から開始)')} → 実際 ${esc(local(r.startedAt))}${d === null ? '' : `(${Math.abs(d)}分${d < 0 ? '早い' : '遅い'})`}<br>計測 ${Math.round(measured(r) / 6e4)}分 / ${ACH[r.achieve]} / 集中 ${r.focus ?? '未回答'}<br>困ったこと:${esc(r.trouble) || '-'} 次回:${esc(r.next) || '-'}</div>`; }).join('') : '<p>まだ記録がありません。「今日」から学習を始めて、振り返りまで保存するとここに出ます。</p>') + '</section>';
}
const COLS = [['id', '記録ID'], ['subject', '教科'], ['task', '課題(自由記述)'], ['mode', '開始方式 planned/now'], ['plannedStart', '開始予定(ISO8601)'], ['startedAt', '開始(ISO8601)'], ['endedAt', '終了(ISO8601)'], ['min', '計測時間(分)'], ['diff', '予定との差(分・マイナスは早い)'], ['achieve', '達成 full/part/none'], ['focus', '集中(1-5・空欄=未回答)'], ['trouble', '困ったこと(自由記述)'], ['next', '次回試すこと(自由記述)'], ['edited', '終了日時修正(1=あり)']];
const FREE = ['task', 'trouble', 'next'];
function dataView(recs) {
  return `<section><h2>この端末の記録</h2><p class="note">記録はこの端末・このブラウザにだけ保存されます。他の端末へは自動で共有されず、ブラウザのデータ削除で消えます。共有の端末では、同じブラウザを使う人が記録を見られます。外部へは送信しません。</p>
<div class="row"><button data-act="json">JSONで書き出す</button><label class="opt"><button type="button" onclick="document.getElementById('imp').click()">JSONを読み込む</button></label><input id="imp" type="file" accept=".json,application/json" hidden></div></section>
<section><h2>CSVで書き出す</h2><p class="note">出す項目を選べます。自由記述と課題名は、初期状態では含みません。</p>${COLS.map(([k, l]) => `<label class="opt"><input type="checkbox" class="col" value="${k}" ${FREE.includes(k) ? '' : 'checked'}>${esc(l)}</label>`).join('<br>')}<div class="row"><button class="p" data-act="csv">CSVを書き出す</button></div></section>
<section><h2>全件削除</h2><p class="note">このアプリの学習記録と課題だけを消します。</p><button data-act="wipe">全件削除</button></section>`;
}

// ===== ポモドーロ風の区切り(教科ごとの最初の値。目安であり、強制や最適の主張はしない) =====
const PRESETS = [[/数学|算数|物理|化学|理科/, 30, 5], [/英|国語|古文|漢文|現代文/, 25, 5], [/社会|歴史|地理|公民|生物|暗記/, 20, 5]];
const preset = s => { const p = PRESETS.find(x => x[0].test(s)); return p ? [p[1], p[2]] : [25, 5]; };
// 計測時間が「区切り×回数」に達したら true(休憩は促すだけで、止めない)
const due = r => r.work > 0 && r.status === 'running' && measured(r) >= (r.seg || 1) * r.work * 6e4;
function breakNote(r) {
  if (r.status === 'paused') return `<p class="note" style="text-align:center">一時停止中(この時間は計測に入りません)。${r.brk > 0 ? `休憩の目安は${r.brk}分です。長くても短くても大丈夫です。` : ''}</p>`;
  if (due(r)) return `<div class="err" style="color:var(--ink);border-color:var(--ac)" role="status">設定した区切り(${r.work}分)になりました。休憩しますか?<div class="row"><button class="p" data-act="pause" data-id="${esc(r.id)}">休憩する</button><button data-act="more" data-id="${esc(r.id)}">もう少し続ける</button></div></div>`;
  return `<p class="note" style="text-align:center">計測中${r.work > 0 ? `(区切りの目安 ${r.work}分。強制ではありません)` : ''}</p>`;
}

// ===== 前回の振り返りからのヒント(ルールで出す簡単な提案。効果や原因の判定ではない) =====
function adviceView(recs) {
  const p = recs.filter(r => r.status === 'done').sort((a, b) => t(b.startedAt) - t(a.startedAt))[0];
  if (!p) return '';
  const d = startDiff(p), tips = [];
  if (p.achieve !== 'full') tips.push('終了条件を2つに分ける/最初の一歩をもっと小さくする');
  if (p.focus !== null && p.focus <= 2) tips.push('区切りを短めにして、休憩を入れてみる');
  if (d !== null && d > 15) tips.push('始めやすい時刻に変える/5分でできる最初の一歩にする');
  return `<section><h2>前回の振り返り(${esc(local(p.startedAt))}・${esc(p.subject)})</h2>
<p>終了条件:${ACH[p.achieve]} / 集中:${p.focus ?? '未回答'}<br>困ったこと:${esc(p.trouble) || '-'}<br>次回試すこと:${esc(p.next) || '-'}</p>
${tips.length ? '<p><b>今回試せること(選ぶのはあなたです)</b></p><ul>' + tips.map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' : ''}
${p.trouble ? `<button data-act="takeT" data-id="${esc(p.id)}">「困ったこと」を最初の一歩に入れる</button>` : ''}
<p class="note">記録をもとにした簡単なヒントです。うまくいかなかったことを責めるものではなく、方法の効果を判定するものでもありません。</p></section>`;
}

// ===== カレンダー(学習した日に件数を表示。連続記録などは出さない) =====
const dkey = d => { const x = new Date(d); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
function calView(all) {
  if (!cal) { const n = new Date(); cal = { y: n.getFullYear(), m: n.getMonth() }; }
  const by = {}; all.filter(r => r.status === 'done').forEach(r => (by[dkey(r.startedAt)] ||= []).push(r));
  const pre = `${cal.y}-${String(cal.m + 1).padStart(2, '0')}`, n = new Date(cal.y, cal.m + 1, 0).getDate();
  let cells = [...'日月火水木金土'].map(w => `<div class="wd">${w}</div>`).join('') + '<div></div>'.repeat(new Date(cal.y, cal.m, 1).getDay());
  for (let d = 1; d <= n; d++) {
    const k = `${pre}-${String(d).padStart(2, '0')}`, c = (by[k] || []).length;
    cells += `<button class="day${c ? ' on' : ''}" data-act="day" data-id="${k}" aria-pressed="${selDay === k}" aria-label="${cal.m + 1}月${d}日 ${c}件">${d}${c ? `<br><small>${c}件</small>` : ''}</button>`;
  }
  const days = Object.keys(by).filter(k => k.startsWith(pre)).length;
  const sel = selDay && (by[selDay] || []).map(r => `<div class="rec"><b>${esc(r.subject)}</b> ${esc(r.task)}<br>計測 ${Math.round(measured(r) / 6e4)}分 / ${ACH[r.achieve]}</div>`).join('');
  return `<section><h2>学習した日</h2><div class="row"><button data-act="calnav" data-id="-1">前の月</button><button data-act="calnav" data-id="1">次の月</button></div>
<p><b>${cal.y}年${cal.m + 1}月</b>:学習した日 ${days}日</p><div class="cal">${cells}</div>
<p class="note">件数が出ている日が、振り返りまで保存した日です。日付を押すと内容が見られます。</p>${selDay ? (sel || '<p>この日の記録はありません。</p>') : ''}</section>`;
}

// ===== 課題管理(学習記録とは別のキーに保存。既存の記録を壊さない) =====
const TKEY = 'gakushu-app:tasks:v1';
function loadT() { try { const d = JSON.parse(localStorage.getItem(TKEY) || '[]'); return Array.isArray(d) ? d : []; } catch (e) { return []; } }
function saveT(a) {
  try { localStorage.setItem(TKEY, JSON.stringify(a)); return true; }
  catch (e) { msg = '課題を保存できませんでした。ブラウザの保存容量などを確認してください。この変更は残っていません。'; return false; }
}
// 最新の保存内容を読み直してから変更する(連打・複数タブ対策)
function taskMut(id, fn) { const a = loadT(), x = a.find(y => y.id === id); if (x && fn(x, a) !== false) { msg = ''; saveT(a); } render(); }
function addTask() {
  const g = n => $('#' + n).value.trim(), title = g('tTitle');
  if (!title) { msg = '課題名を入れてください。'; return render(); }
  const a = loadT();
  a.push({ id: uid(), title, subject: g('tSub'), due: g('tDue'), done: false, doneAt: null, createdAt: new Date().toISOString() });
  if (saveT(a)) msg = '';
  render();
}
function taskView() {
  const a = loadT(), today = dkey(new Date());
  const open = a.filter(x => !x.done).sort((x, y) => (x.due || '9') > (y.due || '9') ? 1 : -1), done = a.filter(x => x.done);
  const row = x => `<div class="rec"><label class="opt"><input type="checkbox" data-act="tdone" data-id="${esc(x.id)}" ${x.done ? 'checked' : ''}><b>${esc(x.title)}</b></label><br>${esc(x.subject) || '教科なし'} / ${x.due ? '期限 ' + esc(x.due) + (!x.done && x.due < today ? '(期限を過ぎています)' : '') : '期限なし'}
<div class="row">${x.done ? '' : `<button class="p" data-act="tuse" data-id="${esc(x.id)}">この課題で学習する</button>`}<button data-act="tdel" data-id="${esc(x.id)}">削除</button></div></div>`;
  return `<section><h2>課題を追加</h2><label for="tTitle">課題名</label><input id="tTitle" placeholder="例:数学ワーク p.30〜35">
<label for="tSub">教科(任意)</label><input id="tSub" placeholder="例:数学"><label for="tDue">期限(任意)</label><input id="tDue" type="date">
<div class="row"><button class="p" data-act="tadd">追加する</button></div></section>
<section><h2>これからの課題(${open.length}件)</h2>${open.length ? open.map(row).join('') : '<p>課題はまだありません。上のフォームから追加できます。</p>'}</section>
${done.length ? `<section><h2>終えた課題(${done.length}件)</h2>${done.map(row).join('')}</section>` : ''}
<p class="note">課題はこの端末・ブラウザにだけ保存されます(学習記録のJSON/CSVには含まれません)。</p>`;
}

// ===== 書き出し・読み込み =====
function download(name, text, type) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
const day = () => ldt(new Date()).slice(0, 10);
function cell(v) {   // CSV用:数式風の文字列は先頭に ' を付けて無効化し、引用符・改行を正しく囲む
  if (v === null || v === undefined) return '';
  let s = String(v);
  if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function exportCsv() {
  const keys = [...document.querySelectorAll('.col:checked')].map(c => c.value);
  if (!keys.length) { msg = '出す項目を1つ以上選んでください。'; return render(); }
  const rows = load().filter(r => r.status === 'done').map(r => ({ ...r, min: Math.round(measured(r) / 6e4 * 10) / 10, diff: startDiff(r), edited: r.edited ? 1 : 0 }));
  const head = keys.map(k => cell(COLS.find(c => c[0] === k)[1])).join(',');
  download(`gakushu-${day()}.csv`, '\ufeff' + [head, ...rows.map(r => keys.map(k => cell(r[k])).join(','))].join('\r\n') + '\r\n', 'text/csv');
}
const okRec = r => r && typeof r.id === 'string' && r.status === 'done' && typeof r.subject === 'string' && typeof r.task === 'string' && !isNaN(t(r.startedAt)) && !isNaN(t(r.endedAt)) && Array.isArray(r.pauses) && ['full', 'part', 'none'].includes(r.achieve) && (r.focus === null || (Number.isInteger(r.focus) && r.focus >= 1 && r.focus <= 5));
function importJson(file) {
  const fr = new FileReader();
  fr.onload = () => {
    try {
      const d = JSON.parse(fr.result);
      if (!d || d.version !== DATA_VER || !Array.isArray(d.records)) throw new Error('形式が違います');
      const good = d.records.filter(okRec), recs = load(), ids = new Set(recs.map(r => r.id));
      let add = 0, dup = 0;
      for (const r of good) { if (ids.has(r.id)) dup++; else { recs.push(r); ids.add(r.id); add++; } }   // 同じIDは上書きしない
      if (!save(recs)) return render();
      msg = `読み込み完了:追加${add}件、同じIDのため見送り${dup}件、形式が不正で除外${d.records.length - good.length}件。`;
    } catch (e) { msg = '読み込めませんでした(このアプリのJSONではありません)。現在の記録は変わっていません。'; }
    render();
  };
  fr.readAsText(file);
}

// ===== イベント =====
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const id = b.dataset.id, a = b.dataset.act;
  if (a === 'tab') { tab = id; msg = ''; render(); }
  else if (a === 'plan') addPlan(false);
  else if (a === 'plannow') addPlan(true);
  else if (a === 'start') startRec(id);
  else if (a === 'pause') pause(id);
  else if (a === 'resume') resume(id);
  else if (a === 'finish') finish(id);
  else if (a === 'reflect') saveReflect(id);
  else if (a === 'more') more(id);
  else if (a === 'day') { selDay = selDay === id ? null : id; render(); }
  else if (a === 'calnav') { const n = new Date(cal.y, cal.m + +id, 1); cal = { y: n.getFullYear(), m: n.getMonth() }; selDay = null; render(); }
  else if (a === 'takeT') { const r = load().find(x => x.id === id); draft = { ...readForm(), firstStep: '「' + r.trouble + '」を確認する' }; render(); }
  else if (a === 'tadd') addTask();
  else if (a === 'tdone') taskMut(id, x => { x.done = !x.done; x.doneAt = x.done ? new Date().toISOString() : null; });
  else if (a === 'tdel') { if (confirm('この課題を削除します。よろしいですか?')) taskMut(id, (x, arr) => { arr.splice(arr.indexOf(x), 1); }); }
  else if (a === 'tuse') { const x = loadT().find(y => y.id === id); if (x) { draft = { subject: x.subject, task: x.title }; tab = 'today'; render(); } }
  else if (a === 'range') { range = id; render(); }
  else if (a === 'take') { const r = load().find(x => x.id === id); draft = { ...readForm(), firstStep: r.next }; render(); }
  else if (a === 'edit') { const r = load().find(x => x.id === id); draft = { ...r, plannedStart: ldt(new Date(r.plannedStart)), editId: id }; render(); }
  else if (a === 'json') download(`gakushu-${day()}.json`, JSON.stringify({ version: DATA_VER, appVersion: APP_VER, records: load() }, null, 1), 'application/json');
  else if (a === 'csv') exportCsv();
  else if (a === 'wipe' && confirm('このアプリの学習記録と課題をすべて削除します。元に戻せません。よろしいですか?')) { try { localStorage.removeItem(KEY); localStorage.removeItem(TKEY); broken = false; msg = '削除しました。'; } catch (x) { msg = '削除できませんでした。'; } render(); }
});
document.addEventListener('change', e => {
  if (e.target.id === 'imp' && e.target.files[0]) importJson(e.target.files[0]);
  if (e.target.id === 'subject' && !$('#work').dataset.t) { const [w, b] = preset(e.target.value); $('#work').value = w; $('#brk').value = b; }  // 自分で変えていない間だけ自動設定
});
document.addEventListener('input', e => { if (e.target.id === 'work' || e.target.id === 'brk') { $('#work').dataset.t = '1'; } });
// 経過時間は保存した時刻から毎回計算する(タイマーの回数は使わない)
function tick() {
  const c = $('#clock'), r = load().find(x => x.status === 'running' || x.status === 'paused');
  if (c && r) c.textContent = fmt(measured(r));
  const d = !!(r && due(r)); if (d !== lastDue) { lastDue = d; render(); }   // 区切りに達した瞬間だけ画面を更新
}
setInterval(tick, 1000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) render(); });  // 画面復帰時に再計算
window.addEventListener('storage', e => { if (e.key === KEY) render(); });                 // 別タブの変更を反映
render();
